sudo chmod +x abandon_order.sh
sudo chown root:root abandon_order.sh 